<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CreateProduct extends FormRequest
{

    public function rules(): array
    {
        $imgRules = ['required', 'image', 'mimes:jpeg,png,jpg,webp', 'max:2048'];

        if ($this->isMethod('put')) {
            $imgRules = ['nullable', 'image', 'mimes:jpeg,png,jpg,webp', 'max:2048'];
        }
        return [
            'name' => ['required', 'string', 'max:255', 'regex:/^[а-яА-ЯёЁ0-9\s]+$/ui'],
            'price' => ['required', 'numeric', 'min:1', 'max:1000000000000'],
            'catigory_id' => ['required', 'integer', 'min:1'],
            'quantity' => ['required', 'integer', 'min:0'],
            'img' => $imgRules,
            'model' => ['required', 'string', 'max:100', 'regex:/^[a-zA-Z0-9\s]+$/i'],
            'year' => ['required', 'integer', 'min:1920', 'max:2100'],
            'country' => ['required', 'string', 'max:100', 'regex:/^[a-zA-Z0-9\s]+$/i'],
        ];
    }

    public function messages(): array
    {
        return [
            'name.required' => 'Название товара обязательно для заполнения.',
            'name.max' => 'Название не может быть длиннее 255 символов.',
            'name.regex' => 'В названии можно использовать только русские буквы, цифры и пробелы.',

            'price.required' => 'Цена обязательна для заполнения.',
            'price.numeric' => 'Цена должна быть числом.',
            'price.min' => 'Минимальная цена — 1 рубль.',
            'price.max' => 'Максимальная цена не может превышать 1 000 000 000 000 рублей.',

            'catigory_id.required' => 'Необходимо выбрать категорию товара.',
            'quantity.required' => 'Количество обязательно для заполнения.',
            'quantity.integer' => 'Количество должно быть целым числом.',
            'quantity.min' => 'Количество не может быть отрицательным.',

            'img.required' => 'Загрузите изображение товара.',
            'img.image' => 'Загруженный файл должен быть изображением.',
            'img.mimes' => 'Допустимые форматы: jpeg, png, jpg, webp.',
            'img.max' => 'Размер изображения не должен превышать 2 МБ.',

            'model.required' => 'Модель товара обязательна для заполнения.',
            'model.max' => 'Модель не может быть длиннее 100 символов.',
            'model.regex' => 'Модель может содержать только латинские буквы, цифры и пробелы.',


            'year.required' => 'Год выпуска обязателен для заполнения.',
            'year.integer' => 'Год должен быть числом.',
            'year.min' => 'Год не может быть раньше 1920.',
            'year.max' => 'Год не может быть позже 2100.',


            'country.required' => 'Страна производства обязательна для заполнения.',
            'country.max' => 'Название страны не может быть длиннее 100 символов.',
            'country.regex' => 'Страна может содержать только латинские буквы, цифры и пробелы.',
        ];
    }
}
