<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CreateCategory extends FormRequest
{

    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:255', 'regex:/^[а-яА-ЯёЁ0-9\s]+$/ui'],

        ];
    }

    public function messages(): array
    {
        return [
            'name.required' => 'Название товара обязательно для заполнения.',
            'name.max' => 'Название не может быть длиннее 255 символов.',
            'name.regex' => 'В названии можно использовать только русские буквы, цифры и пробелы.',

        ];
    }
}
