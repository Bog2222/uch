<?php

namespace App\Http\Controllers;

use App\Services\ProductServices;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\User;
use App\Models\Cart;
use App\Models\Order;
use App\Models\Status;
use App\Models\Category;

class CatalogController extends Controller
{
    public function index(Request $request, ProductServices $productServices)
    {
        $cats = Category::orderBy('name', 'asc')->get();

        $products = $productServices->filter($request)->sort($request)->paginate(5);

        return view("Catalog", compact("cats", "products"));
    }
    // страница продукта
    public function product($id)
    {
        $product = Product::select('id', 'name', 'img', 'price', 'catigory_id', 'year', 'model', 'country', 'quantity')->with('category')->findOrFail($id);

        return view("product", compact("product"));
    }
}
