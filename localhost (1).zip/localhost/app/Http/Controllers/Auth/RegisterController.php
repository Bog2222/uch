<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use App\Models\User;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => ['required', 'string', 'max:255', 'regex:/^[а-яА-ЯёЁ0-9\-]+$/ui'],
            'surname' => ['required', 'string', 'max:255', 'regex:/^[а-яА-ЯёЁ0-9\s\-]+$/ui'],
            'patronymic' => ['nullable', 'string', 'max:255', 'regex:/^[а-яА-ЯёЁ0-9\s\-]+$/ui'],
            'login' => ['required', 'string', 'max:255', 'unique:users', 'regex:/^[a-zA-Z0-9\s\-]+$/i'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:6', 'confirmed'],
            'rules' => ['required'],

        ],
        [
            'name.required' => 'Имя обязательно для заполнения.',
            'name.max' => 'Имя не может быть длиннее 255 символов.',
            'name.regex' => 'В имени можно использовать только русские буквы, цифры и дефис.',
            'surname.required' => 'Фамилия обязательна для заполнения.',
            'surname.max' => 'Фамилия не может быть длиннее 255 символов.',
            'surname.regex' => 'В фамилии можно использовать только русские буквы, цифры, пробелы и дефис.',
            'patronymic.max' => 'Отчество не может быть длиннее 255 символов.',
            'patronymic.regex' => 'В отчестве можно использовать только русские буквы, цифры, пробелы и дефис.',
            'login.required' => 'Логин обязателен для заполнения.',
            'login.max' => 'Логин не может быть длиннее 255 символов.',
            'login.unique' => 'Такой логин уже занят, выберите другой.',
            'login.regex' => 'Логин может содержать только латинские буквы, цифры, пробелы и дефис.',
            'email.required' => 'Email обязателен для заполнения.',
            'email.email' => 'Укажите корректный адрес электронной почты.',
            'email.max' => 'Email не может быть длиннее 255 символов.',
            'email.unique' => 'Пользователь с таким email уже зарегистрирован.',
            'password.required' => 'Пароль обязателен для заполнения.',
            'password.min' => 'Пароль должен быть не короче 6 символов.',
            'password.confirmed' => 'Пароли в полях не совпадают.',
            'rules.required' => 'Необходимо принять правила сайта.',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\Models\User
     */
    protected function create(array $data)
    {
        return User::create([
            'name' => $data['name'],
            'surname' => $data['surname'],
            'patronymic' => $data['patronymic'],
            'login' => $data['login'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
        ]);
    }
}
