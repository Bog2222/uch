<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateCategory;
use App\Http\Requests\CreateProduct;
use App\Models\Category;
use App\Models\Order;
use App\Models\Product;
use App\Services\AdminServices;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    protected $adminService;

    public function __construct(AdminServices $adminService)
    {
        $this->adminService = $adminService;
    }

    public function admin()
    {
        return view('admin');
    }

    public function admin_products()
    {
        $products = Product::with('category')->orderBy('id', 'desc')->get();
        $categories = Category::orderBy('name', 'asc')->get();

        return view('admin_products', compact('products', 'categories'));
    }

    public function admin_catygories()
    {
        $categories = Category::with('products')->orderBy('id', 'desc')->get();
        return view('admin_catygories', compact('categories'));
    }

    public function admin_orders(Request $request)
    {
        $query = Order::with(['user', 'status'])->orderBy('id', 'desc');

        if ($request->has('status') && $request->status != '') {
            $query->whereHas('status', function($q) use ($request) {
                $q->where('name', $request->status);
            });
        }

        $orders = $query->get();
        return view('admin_orders', compact('orders'));
    }

    public function confirmOrder($id)
    {
        $this->adminService->confirmOrder($id);
        return redirect()->back()->with('success');
    }

    public function rejectOrder(Request $request, $id)
    {
        $request->validate([
            'rejection' => 'required|string|max:255',
        ]);

        $this->adminService->rejectOrder($id, $request->input('rejection'));
        return redirect()->back()->with('success');
    }

    public function product_create(CreateProduct $request)
    {
        $this->adminService->newProduct()->createImg($request)->createOrUpdate($request)->save();

        return redirect()->route('admin-products')->with('success');
    }

    public function product_delete(Request $request)
    {
        $this->adminService->findProduct($request->id)->deleteImg()->delete();
        return redirect()->back();
    }

    public function update($id)
    {
        $product = Product::findOrFail($id);
        $categories = Category::orderBy('name', 'asc')->get();
        return view('admin_product_update', compact('product', 'categories'));
    }

    public function product_update(CreateProduct $request)
    {
        $this->adminService->findProduct($request->id)->createImg($request)->createOrUpdate($request)->save();

        return redirect()->route('admin-products')->with('success');
    }

    public function storeCategory(CreateCategory $request)
    {
        $validated = $request->validated();
        $this->adminService->storeCategory($validated['name']);
        return redirect()->route('admin-catygories')->with('success');
    }

    public function destroyCategory($id)
    {
        $this->adminService->destroyCategory($id);
        return redirect()->route('admin-catygories')->with('success');
    }
}
