<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\User;
use App\Models\Cart;
use App\Models\Order;
use App\Models\Status;
use App\Models\Category;

class MainController extends Controller
{
    public function index(){
        return view("main");
    }
    public function about(){
        $products=Product::select('id', 'name', 'img')->orderBy('id', 'desc')->limit(5)->get();
        return view("about", compact("products"));
    }
    public function find_us(){
        return view("find_us");
    }

}
