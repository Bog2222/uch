<?php

namespace App\Http\Controllers;

use App\Services\LkServices;
use Illuminate\Http\Request;

class LkController extends Controller
{
    protected LkServices $lkServices;

    public function __construct(LkServices $lkServices)
    {
        $this->middleware('auth');
        $this->lkServices = $lkServices;
    }

    public function cart()
    {
        $cartItems = $this->lkServices->getCartItems();
        $totalPrice = $this->lkServices->getTotalPrice();

        return view('cart', compact('cartItems', 'totalPrice'));
    }

    public function addToCart(Request $request)
    {
        $this->lkServices->addToCart($request->product_id);
        return redirect()->route('cart')->with('success');
    }

    public function plusCart(Request $request)
    {
        $this->lkServices->plusCart($request->product_id);
        return redirect()->route('cart');
    }

    public function minusCart(Request $request)
    {
        $this->lkServices->minusCart($request->product_id);
        return redirect()->route('cart');
    }

    public function removeFromCart($productId)
    {
        $this->lkServices->removeFromCart($productId);
        return redirect()->route('cart')->with('success');
    }

    public function storeOrder(Request $request)
    {
        $request->validate([
            'password' => 'required|string'
        ]);

        try {
            $this->lkServices->checkout($request->password);
        } catch (\Exception $e) {
            if ($e instanceof \Illuminate\Validation\ValidationException) {
                throw $e;
            }
            return redirect()->route('cart')->with('error', $e->getMessage());
        }

        return redirect()->route('order')->with('success', 'Заказ успешно оформлен');
    }

    public function order()
    {
        $orders = $this->lkServices->getOrders();
        return view("order", compact("orders"));
    }

    public function deleteOrder($id)
    {
        $this->lkServices->cancelOrder($id);
        return redirect()->route('order')->with('success');
    }
}
