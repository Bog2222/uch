<?php

namespace App\Repositories;
use App\Models\Product;
use Illuminate\Http\Request;

interface ProductRepositoryInterface
{
    public function make(): Product;
    public function findOrFail( int $id): Product;
    public function save(Product $product): Product;
    public function delete(Product $product): bool;
    public function FindProductNotNull( int $id): Product;



}
