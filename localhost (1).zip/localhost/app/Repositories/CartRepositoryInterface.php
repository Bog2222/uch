<?php

namespace App\Repositories;

use App\Models\Cart;
use App\Models\Product;
use Illuminate\Database\Eloquent\Collection;

interface CartRepositoryInterface
{
    public function getCartItems(): Collection;
    public function getCartCount(): int;
    public function getTotalPrice(): float;
    public function create(array $data): Cart;
    public function incrementQuantity(int $product_id): int;
    public function decrementQuantity(int $product_id): int;
    public function delete(int $product_id): int;
}

