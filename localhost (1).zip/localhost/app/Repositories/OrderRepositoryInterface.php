<?php

namespace App\Repositories;

use App\Models\Order;
use Illuminate\Database\Eloquent\Collection;

interface OrderRepositoryInterface
{
    public function create(array $data): Order;
    public function getUserOrders(int $user_id): Collection;
    public function findOrFail(int $id): Order;
    public function delete(Order $order): bool;
    public function updateStatus(Order $order, int $status_id): Order;
}