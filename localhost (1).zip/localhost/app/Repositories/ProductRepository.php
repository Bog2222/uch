<?php

namespace App\Repositories;

use App\Models\Product;

class ProductRepository implements ProductRepositoryInterface
{
    public function make(): Product
    {
        return new Product();
    }

    public function findOrFail($id): Product
    {
        return Product::findOrFail($id);
    }

    public function save(Product $product): Product
    {
        $product->save();
        return $product;
    }

    public function delete(Product $product): bool
    {
        return $product->delete();
    }

    public function FindProductNotNull(int $id): Product
    {
        return Product::where('quantity', '>', 0)->findOrFail($id);
    }
}