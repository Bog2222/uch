<?php

namespace App\Repositories;

use App\Models\Cart;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class CartRepository implements CartRepositoryInterface
{
    public function getCartItems(): Collection
    {
        return Cart::select(
                'products.id as product_id',
                'products.name as name',
                'products.price as price',
                'products.quantity as max_quantity',
                'cart.quantity as quantity',
                'products.img as img',
                'products.model as model'
            )
            ->where('cart.user_id', Auth::id())
            ->join('products', 'cart.product_id', '=', 'products.id')
            ->get();
    }

    public function getCartCount(): int
    {
        return Cart::where('user_id', Auth::id())->count();
    }

    public function getTotalPrice(): float
    {
        return (float) Cart::where('cart.user_id', Auth::id())
            ->join('products', 'cart.product_id', '=', 'products.id')
            ->sum(DB::raw('products.price * cart.quantity'));
    }

    public function create(array $data): Cart
    {
        return Cart::create($data);
    }

    public function incrementQuantity(int $product_id): int
    {
        return Cart::where('user_id', Auth::id())
                   ->where('product_id', $product_id)
                   ->increment('quantity');
    }

    public function decrementQuantity(int $product_id): int
    {
        return Cart::where('user_id', Auth::id())
                   ->where('product_id', $product_id)
                   ->decrement('quantity');
    }

    public function delete(int $product_id): int
    {
        return Cart::where('user_id', Auth::id())
                   ->where('product_id', $product_id)
                   ->delete();
    }
}