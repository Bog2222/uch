<?php

namespace App\Repositories;

use App\Models\Order;
use Illuminate\Database\Eloquent\Collection;

class OrderRepository implements OrderRepositoryInterface
{
    public function create(array $data): Order
    {
        return Order::create($data);
    }

    public function getUserOrders(int $user_id): Collection
    {
        return Order::where('user_id', $user_id)
            ->with('status')
            ->withSum('items as quantity', 'quantity')
            ->orderBy('id', 'desc')
            ->get();
    }

    public function findOrFail(int $id): Order
    {
        return Order::findOrFail($id);
    }

    public function delete(Order $order): bool
    {
        return $order->delete();
    }

    public function updateStatus(Order $order, int $status_id): Order
    {
        $order->status_id = $status_id;
        $order->save();
        return $order;
    }
}
