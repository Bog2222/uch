<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Category;

class Product extends Model
{
    use HasFactory;
    
    protected $table = "products";
    protected $primaryKey = "id";
    public $timestamps = false;
    
    protected $fillable = [
        'img',
        'name',
        'price',
        'country',
        'catigory_id',
        'model',
        'year',
        'quantity'
    ];

    public function category(){
        return $this->belongsTo(Category::class, 'catigory_id', 'id');
    }
}



