<?php

namespace App\Services;

use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Builder;

class ProductServices
{
    protected Builder $query;

    public function __construct()
    {
        $this->query = Product::select('id', 'name', 'price', 'img', 'catigory_id', 'year', 'model', 'country', 'quantity')->where('quantity', '>', 0);
    }

    public function filter(Request $request)
    {
        if ($request->filled('category') && $request->category != 0) {
            $this->query->where('catigory_id', $request->input('category'));
        }

        if ($request->filled('search')) {
            $search = $request->input('search');
            $this->query->where(function(Builder $q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                    ->orWhere('model', 'like', "%{$search}%")
                    ->orWhere('year', 'like', "%{$search}%")
                    ->orWhere('country', 'like', "%{$search}%");
            });
        }

        return $this;
    }

    public function sort(Request $request)
    {
        switch ($request->input('sort')) {
            case '1': $this->query->orderBy('year', 'asc'); break;
            case '2': $this->query->orderBy('year', 'desc'); break;
            case '3': $this->query->orderBy('name', 'asc'); break;
            case '4': $this->query->orderBy('name', 'desc'); break;
            case '5': $this->query->orderBy('price', 'desc'); break;
            case '6': $this->query->orderBy('price', 'asc'); break;
            default:  $this->query->orderBy('id', 'desc');
        }
        return $this;
    }

    public function paginate(int $page = 5)
    {
        return $this->query->paginate($page);
    }
}
