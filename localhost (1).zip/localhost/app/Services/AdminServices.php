<?php

namespace App\Services;

use App\Models\Product;
use App\Repositories\CategoryRepositoryInterface;
use App\Repositories\OrderRepositoryInterface;
use App\Repositories\ProductRepositoryInterface;
use Illuminate\Http\Request;

class AdminServices
{
    protected $products;
    protected ProductRepositoryInterface $productRepository;
    protected CategoryRepositoryInterface $categoryRepository;
    protected OrderRepositoryInterface $orderRepository;

    public function __construct(
        ProductRepositoryInterface $productRepository,
        CategoryRepositoryInterface $categoryRepository,
        OrderRepositoryInterface $orderRepository
    ) {
        $this->productRepository = $productRepository;
        $this->categoryRepository = $categoryRepository;
        $this->orderRepository = $orderRepository;
    }

    public function newProduct()
    {
        $this->products = $this->productRepository->make();
        return $this;
    }

    public function findProduct($id)
    {
        $this->products = $this->productRepository->findOrFail($id);
        return $this;
    }

    public function createImg(Request $request)
    {
        if ($request->hasFile('img')) {
            $fileName = time() . '_' . $request->file('img')->getClientOriginalName();
            $request->file('img')->move(public_path('img'), $fileName);
            $this->products->img = $fileName;
        }
        return $this;
    }

    public function createOrUpdate(Request $request)
    {
        $this->products->name = $request->input('name');
        $this->products->price = $request->input('price');
        $this->products->country = $request->input('country');
        $this->products->year = $request->input('year');
        $this->products->model = $request->input('model');
        $this->products->catigory_id = $request->input('catigory_id');

        if ($request->filled('quantity')) {
            $this->products->quantity = $request->input('quantity');
        }

        return $this;
    }

    public function deleteImg()
    {
        if ($this->products->img && file_exists(public_path('img/' . $this->products->img))) {
            unlink(public_path('img/' . $this->products->img));
        }
        return $this;
    }

    public function delete()
    {
        $this->products->delete();
        return $this->products;
    }

    public function save()
    {
        $this->products->save();
        return $this->products;
    }

    public function storeCategory($name)
    {
        $this->categoryRepository->create(['name' => $name]);
    }

    public function destroyCategory($id)
    {
        $category = $this->categoryRepository->findOrFail($id);
        $this->categoryRepository->delete($category);
    }

    public function confirmOrder($id)
    {
        $order = $this->orderRepository->findOrFail($id);
        $this->orderRepository->updateStatus($order, 5);
    }

    public function rejectOrder($id, $rejection)
    {
        $order = $this->orderRepository->findOrFail($id);
        $order->status_id = 3;
        $order->rejection = $rejection;
        $order->save();
    }
}