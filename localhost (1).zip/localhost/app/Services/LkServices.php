<?php

namespace App\Services;

use App\Models\Cart;
use App\Models\Orderitem;
use App\Repositories\CartRepositoryInterface;
use App\Repositories\ProductRepositoryInterface;
use App\Repositories\OrderRepositoryInterface;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class LkServices
{
    protected CartRepositoryInterface $cartRepository;
    protected ProductRepositoryInterface $productRepository;
    protected OrderRepositoryInterface $orderRepository;

    public function __construct(
        CartRepositoryInterface $cartRepository,
        ProductRepositoryInterface $productRepository,
        OrderRepositoryInterface $orderRepository
    ) {
        $this->cartRepository = $cartRepository;
        $this->productRepository = $productRepository;
        $this->orderRepository = $orderRepository;
    }

    public function getCartItems()
    {
        return $this->cartRepository->getCartItems();
    }

    public function getTotalPrice(): float
    {
        return $this->cartRepository->getTotalPrice();
    }

    public function addToCart($productId)
    {
        $product = $this->productRepository->findOrFail($productId);

        if ($product->quantity <= 0) {
            throw new \Exception('Товар недоступен');
        }

        $cartItem = Cart::where('user_id', Auth::id())
            ->where('product_id', $productId)
            ->first();

        if ($cartItem) {
            if ($cartItem->quantity < $product->quantity) {
                $this->cartRepository->incrementQuantity($productId);
            }
        } else {
            $this->cartRepository->create([
                'user_id' => Auth::id(),
                'product_id' => $productId,
                'quantity' => 1
            ]);
        }
    }

    public function plusCart($productId)
    {
        $product = $this->productRepository->findOrFail($productId);
        $cartItem = Cart::where('user_id', Auth::id())
            ->where('product_id', $productId)
            ->first();

        if ($cartItem && $cartItem->quantity < $product->quantity) {
            $this->cartRepository->incrementQuantity($productId);
        }
    }

    public function minusCart($productId)
    {
        $cartItem = Cart::where('user_id', Auth::id())
            ->where('product_id', $productId)
            ->first();

        if ($cartItem) {
            if ($cartItem->quantity > 1) {
                $this->cartRepository->decrementQuantity($productId);
            } else {
                $this->cartRepository->delete($productId);
            }
        }
    }

    public function removeFromCart($productId)
    {
        $this->cartRepository->delete($productId);
    }

    public function checkout(string $password)
    {
        if (!Hash::check($password, Auth::user()->password)) {
            throw ValidationException::withMessages([
                'password' => 'Пароль не правильный'
            ]);
        }

        $cartItems = $this->cartRepository->getCartItems();

        if ($cartItems->isEmpty()) {
            throw new \Exception('Корзина пуста');
        }

        DB::transaction(function () use ($cartItems) {
            $totalPrice = $this->cartRepository->getTotalPrice();

            $order = $this->orderRepository->create([
                'user_id' => Auth::id(),
                'status_id' => 2,
                'total_price' => $totalPrice,
                'rejection' => '',
            ]);

            foreach ($cartItems as $item) {
                Orderitem::create([
                    'order_id' => $order->id,
                    'product_id' => $item->product_id,
                    'quantity' => $item->quantity
                ]);

                $product = $this->productRepository->findOrFail($item->product_id);
                $product->decrement('quantity', $item->quantity);
            }

            Cart::where('user_id', Auth::id())->delete();
        });

        return true;
    }

    public function getOrders()
    {
        return $this->orderRepository->getUserOrders(Auth::id());
    }

    public function cancelOrder($id)
    {
        $order = $this->orderRepository->findOrFail($id);

        if ($order->user_id === Auth::id() && $order->status_id == 2) {
            DB::transaction(function () use ($order) {
                $items = Orderitem::where('order_id', $order->id)->get();
                foreach ($items as $item) {
                    $product = $this->productRepository->findOrFail($item->product_id);
                    $product->increment('quantity', $item->quantity);
                }

                Orderitem::where('order_id', $order->id)->delete();
                $this->orderRepository->delete($order);
            });
        }
    }

}
