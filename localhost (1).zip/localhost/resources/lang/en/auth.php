<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed' => 'Неверный логин или пароль.',
    'password' => 'Неверный логин или пароль.',
    'throttle' => 'система временно заблокировала вход с вашего устройства или IP-адреса из-за слишком большого числа неудачных попыток входа',

];
