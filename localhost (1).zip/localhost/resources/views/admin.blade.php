@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Админ-панель </h1>
        <a href="{{ route('admin-products') }}" class="btn btn-primary btn-lg px-5">Управление товарами</a>
        <a href="{{ route('admin-catygories') }}" class="btn btn-primary btn-lg px-5">Управление категориями</a>
        <a href="{{ route('admin-orders') }}" class="btn btn-primary btn-lg px-5">Управление заказами</a>
@endsection
