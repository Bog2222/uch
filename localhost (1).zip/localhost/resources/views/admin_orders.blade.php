@extends('layouts.app')

@section('content')
    <div class="container">

        <div class="mb-3">
            <a href="?status=Новый" class="btn btn-sm btn-info">Новые</a>
            <a href="?status=Подтвержденный" class="btn btn-sm btn-success">Подтвержденные</a>
            <a href="?status=Отменено" class="btn btn-sm btn-danger">Отмененные</a>
            <a href="?" class="btn btn-sm btn-secondary">Все</a>
        </div>

        <table class="table table-hover align-middle">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">ФИО заказчика</th>
                <th scope="col">Дата заказа</th>
                <th scope="col">Кол-во товаров</th>
                <th scope="col">Статус</th>
                <th scope="col">Причина отмены</th>
                <th scope="col">Действия</th>
            </tr>
            </thead>
            <tbody>
            @foreach ($orders as $order)
                <tr>
                    <th scope="row">
                        <button type="button" class="btn btn-link p-0 text-decoration-none fw-bold" data-bs-toggle="modal" data-bs-target="#orderModal{{ $order->id }}">
                            #{{ $order->id }}
                        </button>
                    </th>
                    <td>{{ $order->user->name ?? 'Неизвестный' }}</td>
                    <td>{{ $order->created_at ? $order->created_at->format('d.m.Y H:i') : '—' }}</td>
                    <td>{{ $order->items->sum('quantity') }} шт.</td>
                    <td>{{ $order->status->name ?? '—' }}</td>
                    <td>{{ $order->rejection ?? '—' }}</td>
                    <td>
                        @if($order->status_id == 2)
                            <form action="{{ route('admin-orders.confirm', $order->id) }}" method="POST" class="d-inline">
                                @csrf
                                <button type="submit" class="btn btn-sm btn-success">Подтвердить</button>
                            </form>

                            <form action="{{ route('admin-orders.reject', $order->id) }}" method="POST" class="d-inline">
                                @csrf
                                <input type="text" name="rejection" class="form-control form-control-sm d-inline-block" style="width: 150px;" placeholder="Причина отмены" required>
                                <button type="submit" class="btn btn-sm btn-danger">Отменить</button>
                            </form>
                        @else
                            <span class="text-muted">Завершен</span>
                        @endif
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>

        @foreach ($orders as $order)
            <div class="modal fade" id="orderModal{{ $order->id }}" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Состав заказа #{{ $order->id }}</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <strong>Заказчик:</strong> {{ $order->user->name }}
                            </div>
                            <div class="table-responsive">
                                <table class="table table-bordered align-middle">
                                    <thead class="table-light">
                                    <tr>
                                        <th>Товар</th>
                                        <th>Количество</th>
                                        <th>Цена</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($order->items as $item)
                                        <tr>
                                            <td>{{ $item->product->name ?? 'Товар удален' }}</td>
                                            <td>{{ $item->quantity }} шт.</td>
                                            <td>{{ number_format(($item->product->price ?? 0) * $item->quantity, 0, '.', ' ') }} руб.</td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                            <div class="text-end mt-3">
                                <h4>Итого: {{ number_format($order->total_price, 0, '.', ' ') }} руб.</h4>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
                        </div>
                    </div>
                </div>
            </div>
        @endforeach

        <a href="{{ route('admin') }}" class="btn btn-outline-secondary mt-3">Назад</a>
    </div>
@endsection