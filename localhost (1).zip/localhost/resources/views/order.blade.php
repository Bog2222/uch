@extends('layouts.app')

@section('content')
    <div class="container py-4">
        <h1 class="mb-4">Мои заказы</h1>

        @if(session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif

        @if($orders->isEmpty())
            <div class="text-center py-5">
                <h3>У вас пока нет заказов</h3>
                <a href="{{ route('catalog') }}" class="btn btn-primary mt-3">Перейти в каталог</a>
            </div>
        @else
            <div class="table-responsive">
                <table class="table table-bordered align-middle">
                    <thead class="table-light">
                    <tr>
                        <th>Заказ</th>
                        <th>Количество товаров</th>
                        <th>Статус</th>
                        <th>Итоговая цена</th>
                        <th>Дата оформления</th>
                        <th>Удаление</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($orders as $order)
                        <tr>
                            <td>
                                <button type="button" class="btn btn-link p-0 text-decoration-none fw-bold" data-bs-toggle="modal" data-bs-target="#userOrderModal{{ $order->id }}">
                                    #{{ $order->id }}
                                </button>
                            </td>
                            <td>{{ $order->quantity }} шт.</td>
                            <td>
                            <span class="badge {{ $order->status_id == 1 ? 'bg-success' : ($order->status_id == 3 ? 'bg-danger' : 'bg-warning') }}">
                                {{ $order->status->name ?? 'Неизвестно' }}
                            </span>
                            </td>
                            <td>{{ number_format($order->total_price, 0, '.', ' ') }} руб.</td>
                            <td>{{ $order->created_at ? $order->created_at->format('d.m.Y H:i') : '—' }}</td>
                            <td>
                                @if($order->status_id == 2)
                                    <form action="{{ route('order.delete', $order->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Удалить заказ?');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-sm btn-outline-danger">Удалить</button>
                                    </form>
                                @else
                                    <span class="text-muted small">Недоступно</span>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>

            @foreach($orders as $order)
                <div class="modal fade" id="userOrderModal{{ $order->id }}" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-lg modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Детали заказа #{{ $order->id }}</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered align-middle">
                                        <thead class="table-light">
                                        <tr>
                                            <th>Товар</th>
                                            <th>Количество</th>
                                            <th>Цена</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($order->items as $item)
                                            <tr>
                                                <td>{{ $item->product->name ?? 'Товар удален' }}</td>
                                                <td>{{ $item->quantity }} шт.</td>
                                                <td>{{ number_format(($item->product->price ?? 0) * $item->quantity, 0, '.', ' ') }} руб.</td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                                <div class="text-end mt-3">
                                    <h4>Итого: {{ number_format($order->total_price, 0, '.', ' ') }} руб.</h4>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        @endif
    </div>
@endsection
