@extends('layouts.app')

@section('content')
<div class="container py-4">
    <div class="row g-4">
        <div class="col-lg-6">
            <div class="card border-0 shadow-sm">
                @if($product->img)
                    <img src="{{ asset('public/img/' . $product->img) }}" class="card-img-top w-100 object-fit-cover" style="max-height: 500px;" alt="{{ $product->name }}">
                @endif
            </div>
        </div>

        <div class="col-lg-6">
            <h1 class="display-6 fw-bold mb-3">{{ $product->name }}</h1>
            <h2 class="h3 text-primary fw-bold mb-4">{{ number_format($product->price, 0, '.', ' ') }} руб.</h2>

            <div class="mb-4">
                <ul class="list-unstyled">
                    <li class="mb-2"><strong>Страна:</strong> {{ $product->country }}</li>
                    <li class="mb-2"><strong>Год:</strong> {{ $product->year }}</li>
                    <li class="mb-2"><strong>Модель:</strong> {{ $product->model }}</li>
                    <li class="mb-2"><strong>Категория:</strong> {{ $product->category ? $product->category->name : 'Не указана' }}</li>
                    <li class="mb-2"><strong>В наличии:</strong> {{ $product->quantity }} шт.</li>
                </ul>
            </div>

            <div class="d-grid gap-2 d-md-flex mt-5">
                <form action="{{ route('cart.add') }}" method="POST" class="d-inline">
                    @csrf
                    <input type="hidden" name="product_id" value="{{ $product->id }}">
                    <button type="submit" class="btn btn-primary btn-lg px-5" {{ $product->quantity <= 0 ? 'disabled' : '' }}>
                        {{ $product->quantity <= 0 ? 'Нет в наличии' : 'В корзину' }}
                    </button>
                </form>
                <a href="{{ route('catalog') }}" class="btn btn-outline-secondary btn-lg">Назад</a>
            </div>
        </div>
    </div>
</div>
@endsection
