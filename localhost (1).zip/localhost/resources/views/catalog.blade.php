@extends('layouts.app')

@section('content')
    <div class="container py-4">
        <form method="GET" action="{{ route('catalog') }}">
            <div class="row mb-3">
                <div class="col-md-12">
                    <label for="search" class="form-label text-muted small fw-bold">Поиск товаров</label>
                    <input type="text" name="search" class="form-control form-control-lg" id="search"  value="{{ request('search') }}">
                </div>
            </div>

            <div class="row mb-4 align-items-end">
                <div class="col-md-4">
                    <label class="form-label text-muted small fw-bold">Упорядочить</label>
                    <select class="form-select form-select-lg" name="sort" id="sort">
                        <option value="0" {{ request('sort') == 0 ? 'selected' : '' }}>По умолчанию</option>
                        <option value="1" {{ request('sort') == 1 ? 'selected' : '' }}>По году производства: Сначала новые</option>
                        <option value="2" {{ request('sort') == 2 ? 'selected' : '' }}>По году производства: Сначала старые</option>
                        <option value="3" {{ request('sort') == 3 ? 'selected' : '' }}>По наименованию: от А-Я</option>
                        <option value="4" {{ request('sort') == 4 ? 'selected' : '' }}>По наименованию: от Я-А</option>
                        <option value="5" {{ request('sort') == 5 ? 'selected' : '' }}>По цене: Сначала дорогие</option>
                        <option value="6" {{ request('sort') == 6 ? 'selected' : '' }}>По цене: Сначала дешевые</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label text-muted small fw-bold">Категория</label>
                    <select class="form-select form-select-lg" name="category">
                        <option value="0" {{ request('category') == 0 ? 'selected' : '' }}>По умолчанию</option>
                        @foreach($cats as $cat)
                            <option value="{{ $cat->id }}" {{ request('category') == $cat->id ? 'selected' : '' }}>{{ $cat->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-4">
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary btn-lg flex-grow-1">Найти</button>
                        <a href="{{ route('catalog') }}" class="btn btn-outline-secondary btn-lg flex-grow-1">Сбросить</a>
                    </div>
                </div>
            </div>
        </form>

        <div class="row row-cols-1 row-cols-md-3 g-4">
            @foreach($products as $product)
                <div class="col">
                    <div class="card h-100 d-flex flex-column border-0 shadow-sm">
                        <img src="{{ asset('public/img/' . $product->img) }}" alt="{{ $product->name }}">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title fw-bold">{{ $product->name }}</h5>
                            <p class="card-text text-primary fs-5 fw-bold mb-4">{{ number_format($product->price, 0, '.', ' ') }} руб.</p>
                            <a href="{{ route('product', $product->id) }}" class="btn btn-primary mt-auto">Подробнее</a>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>

    <div class="d-flex justify-content-center mt-5">
        {{ $products->appends(request()->query())->links('pagination::bootstrap-4') }}
    </div>
@endsection
