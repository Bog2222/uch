@extends('layouts.app')

@section('content')
    <div class="container py-4">
        <h1 class="mb-4">Ваша корзина</h1>

        @if(session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif
        @if(session('error'))
            <div class="alert alert-danger">{{ session('error') }}</div>
        @endif

        @if($cartItems->isEmpty())
            <div class="text-center py-5">
                <h3>Корзина пуста</h3>
                <a href="{{ route('catalog') }}" class="btn btn-primary mt-3">Перейти в каталог</a>
            </div>
        @else

            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    @foreach($cartItems as $item)

                        <div class="row align-items-center mb-3 pb-3 border-bottom">
                            <div class="col-md-2">
                                @if($item->img)
                                    <img src="{{ asset('public/img/' . $item->img) }}" class="img-fluid rounded" alt="{{ $item->name }}" style="max-width: 80px;">
                                @endif
                            </div>
                            <div class="col-md-4">
                                <h6 class="mb-1">{{ $item->name }}</h6>
                                <small class="text-muted">{{ $item->model }}</small>
                            </div>
                            <div class="col-md-2">
                                <span class="text-primary fw-bold">{{ number_format($item->price, 0, '.', ' ') }} руб.</span>
                            </div>
                            <div class="col-md-2">
                                <div class="d-flex justify-content-center align-items-center">
                                    <form action="{{ route('cart.minus') }}" method="POST" class="d-inline">
                                        @method('PATCH')
                                        @csrf
                                        <input type="hidden" name="product_id" value="{{ $item->product_id }}">
                                        <button class="btn btn-sm btn-outline-secondary" type="submit">-</button>
                                    </form>

                                    <div class="mx-2" style="width: 60px;">
                                        <input type="text" value="{{ $item->quantity }}" class="form-control form-control-sm" style="width: 50px" readonly>
                                    </div>

                                    <form action="{{ route('cart.plus') }}" method="POST" class="d-inline">
                                        @method('PATCH')
                                        @csrf
                                        <input type="hidden" name="product_id" value="{{ $item->product_id }}">
                                        <button class="btn btn-sm btn-outline-secondary" type="submit" {{ $item->quantity >= $item->max_quantity ? 'disabled' : '' }}>+</button>
                                    </form>
                                </div>
                            </div>
                            <div class="col-md-2 text-end" style="margin-left: 7px">
                                <a href="{{ route('cart.remove', $item->product_id) }}" class="btn btn-sm btn-outline-danger">Удалить</a>
                            </div>
                        </div>

                    @endforeach

                    <div class="row mt-3">
                        <div class="col-md-6">
                            <h4>Итого: {{ number_format($totalPrice, 0, '.', ' ') }} руб.</h4>
                        </div>
                    </div>

                    <hr>

                    <div class="row">
                        <div class="col-md-12 text-end">
                            <button type="button" class="btn btn-success btn-lg" data-bs-toggle="modal" data-bs-target="#passwordModal">
                                Оформить заказ
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        @endif
    </div>

    <div class="modal fade @if($errors->has('password')) show @endif" id="passwordModal" tabindex="-1" aria-labelledby="passwordModalLabel" aria-hidden="true" @if($errors->has('password')) style="display: block; background: rgba(0,0,0,0.5);" @endif>
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="passwordModalLabel">Подтверждение заказа</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" onclick="this.closest('.modal').style.display='none'"></button>
                </div>
                <form action="{{ route('order.store') }}" method="POST">
                    @csrf
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="password" class="form-label">Введите пароль для подтверждения заказа:</label>
                            <input type="password" name="password" id="password" class="form-control @error('password') is-invalid @enderror" required>
                            @error('password')
                            <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onclick="this.closest('.modal').style.display='none'">Отмена</button>
                        <button type="submit" class="btn btn-success">Сформировать заказ</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
