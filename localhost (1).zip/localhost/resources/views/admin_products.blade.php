@extends('layouts.app')

@section('content')
    <div class="container py-4">

        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        <button type="button" class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#addProductModal">
            Добавить товар
        </button>

        <table class="table table-bordered align-middle">
            <thead class="table-light">
            <tr>
                <th>#</th>
                <th>Изображение</th>
                <th>Название</th>
                <th>Страна</th>
                <th>Модель</th>
                <th>Год</th>
                <th>Категория</th>
                <th>Цена</th>
                <th>Кол-во</th>
                <th class="text-end">Действия</th>
            </tr>
            </thead>
            <tbody>
            @foreach($products as $product)
                <tr>
                    <td>{{ $product->id }}</td>
                    <td>
                        @if($product->img)
                            <img src="{{ asset('public/img/' . $product->img) }}" style="max-width: 50px;">
                        @else
                            —
                        @endif
                    </td>
                    <td>{{ $product->name }}</td>
                    <td>{{ $product->country }}</td>
                    <td>{{ $product->model }}</td>
                    <td>{{ $product->year }}</td>
                    <td>{{ $product->category ? $product->category->name : '—' }}</td>
                    <td>{{ number_format($product->price, 2) }} ₽</td>
                    <td>{{ $product->quantity }}</td>
                    <td class="text-end">
                        <a href="{{ route('admin.product.update', $product->id) }}">
                            <button type="button" class="btn btn-primary btn-sm mb-1">Изменить</button>
                        </a>
                        <form method="POST" action="{{ route('product.delete') }}" class="d-inline" onsubmit="return confirm('Вы уверены, что хотите удалить этот товар?');">
                            @method('DELETE')
                            @csrf
                            <input type="hidden" name="id" value="{{ $product->id }}">
                            <button type="submit" class="btn btn-danger btn-sm mb-1">Удалить</button>
                        </form>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>

        <a href="{{ route('admin') }}" class="btn btn-outline-secondary">Назад</a>
    </div>

    <div class="modal fade" id="addProductModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Добавить товар</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form action="{{ route('product.create') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Название</label>
                            <input type="text" name="name" class="form-control @error('name') is-invalid @enderror" required>
                            @error('name')
                            <span class="invalid-feedback"><strong>{{ $message }}</strong></span>
                            @enderror
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Изображение</label>
                            <input type="file" name="img" class="form-control @error('img') is-invalid @enderror" accept="image/*" required>
                            @error('img')
                            <span class="invalid-feedback"><strong>{{ $message }}</strong></span>
                            @enderror
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Цена</label>
                            <input type="number" name="price" class="form-control @error('price') is-invalid @enderror" required>
                            @error('price')
                            <span class="invalid-feedback"><strong>{{ $message }}</strong></span>
                            @enderror
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Страна</label>
                            <input type="text" name="country" class="form-control @error('country') is-invalid @enderror" required>
                            @error('country')
                            <span class="invalid-feedback"><strong>{{ $message }}</strong></span>
                            @enderror
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Категория</label>
                            <select name="catigory_id" class="form-control @error('catigory_id') is-invalid @enderror" required>
                                @foreach($categories as $cat)
                                    <option value="{{ $cat->id }}">{{ $cat->name }}</option>
                                @endforeach
                            </select>
                            @error('catigory_id')
                            <span class="invalid-feedback"><strong>{{ $message }}</strong></span>
                            @enderror
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Модель</label>
                            <input type="text" name="model" class="form-control @error('model') is-invalid @enderror" required>
                            @error('model')
                            <span class="invalid-feedback"><strong>{{ $message }}</strong></span>
                            @enderror
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Год</label>
                            <input type="number" name="year" class="form-control @error('year') is-invalid @enderror" required>
                            @error('year')
                            <span class="invalid-feedback"><strong>{{ $message }}</strong></span>
                            @enderror
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Количество</label>
                            <input type="number" name="quantity" class="form-control @error('quantity') is-invalid @enderror" required>
                            @error('quantity')
                            <span class="invalid-feedback"><strong>{{ $message }}</strong></span>
                            @enderror
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
                        <button type="submit" class="btn btn-primary">Добавить</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
