<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="mb-3">
            <a href="?status=Новый" class="btn btn-sm btn-info">Новые</a>
            <a href="?status=Подтвержденный" class="btn btn-sm btn-success">Подтвержденные</a>
            <a href="?status=Отменено" class="btn btn-sm btn-danger">Отмененные</a>
            <a href="?" class="btn btn-sm btn-secondary">Все</a>
        </div>

        <table class="table table-hover align-middle">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">ФИО заказчика</th>
                <th scope="col">Дата заказа</th>
                <th scope="col">Кол-во товаров</th>
                <th scope="col">Статус</th>
                <th scope="col">Причина отмены</th>
                <th scope="col">Действия</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row">
                        <button type="button" class="btn btn-link p-0 text-decoration-none fw-bold" data-bs-toggle="modal" data-bs-target="#orderModal<?php echo e($order->id); ?>">
                            #<?php echo e($order->id); ?>

                        </button>
                    </th>
                    <td><?php echo e($order->user->name ?? 'Неизвестный'); ?></td>
                    <td><?php echo e($order->created_at ? $order->created_at->format('d.m.Y H:i') : '—'); ?></td>
                    <td><?php echo e($order->items->sum('quantity')); ?> шт.</td>
                    <td><?php echo e($order->status->name ?? '—'); ?></td>
                    <td><?php echo e($order->rejection ?? '—'); ?></td>
                    <td>
                        <?php if($order->status_id == 2): ?>
                            <form action="<?php echo e(route('admin-orders.confirm', $order->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-success">Подтвердить</button>
                            </form>

                            <form action="<?php echo e(route('admin-orders.reject', $order->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <input type="text" name="rejection" class="form-control form-control-sm d-inline-block" style="width: 150px;" placeholder="Причина отмены" required>
                                <button type="submit" class="btn btn-sm btn-danger">Отменить</button>
                            </form>
                        <?php else: ?>
                            <span class="text-muted">Завершен</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="modal fade" id="orderModal<?php echo e($order->id); ?>" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Состав заказа #<?php echo e($order->id); ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="mb-3">
                                <strong>Заказчик:</strong> <?php echo e($order->user->name); ?>

                            </div>
                            <div class="table-responsive">
                                <table class="table table-bordered align-middle">
                                    <thead class="table-light">
                                    <tr>
                                        <th>Товар</th>
                                        <th>Количество</th>
                                        <th>Цена</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->product->name ?? 'Товар удален'); ?></td>
                                            <td><?php echo e($item->quantity); ?> шт.</td>
                                            <td><?php echo e(number_format(($item->product->price ?? 0) * $item->quantity, 0, '.', ' ')); ?> руб.</td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="text-end mt-3">
                                <h4>Итого: <?php echo e(number_format($order->total_price, 0, '.', ' ')); ?> руб.</h4>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <a href="<?php echo e(route('admin')); ?>" class="btn btn-outline-secondary mt-3">Назад</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OSPanel\domains\localhost\resources\views/admin_orders.blade.php ENDPATH**/ ?>