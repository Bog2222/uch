

<?php $__env->startSection('content'); ?>
<div class="container " style="width:50%">
    <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="https://avatars.mds.yandex.net/i?id=4bd5caa20fa7f065716a103f5f4173139d9af81a-5475958-images-thumbs&n=13" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://www.sports.kz/upload/live/58448ac647fc3bb8602fec2a209a54bf.jpg_150-150.webp" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="https://avatars.mds.yandex.net/i?id=5522e11c0ee6935886a82a795d5f9a134ad781b7-3780431-images-thumbs&n=13" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\localhost\resources\views/main.blade.php ENDPATH**/ ?>