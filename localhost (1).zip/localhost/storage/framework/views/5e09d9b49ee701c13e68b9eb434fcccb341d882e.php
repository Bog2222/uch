

<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <form method="GET" action="<?php echo e(route('catalog')); ?>">
            <div class="row mb-3">
                <div class="col-md-12">
                    <label for="search" class="form-label text-muted small fw-bold">Поиск товаров</label>
                    <input type="text" name="search" class="form-control form-control-lg" id="search"  value="<?php echo e(request('search')); ?>">
                </div>
            </div>

            <div class="row mb-4 align-items-end">
                <div class="col-md-4">
                    <label class="form-label text-muted small fw-bold">Упорядочить</label>
                    <select class="form-select form-select-lg" name="sort" id="sort">
                        <option value="0" <?php echo e(request('sort') == 0 ? 'selected' : ''); ?>>По умолчанию</option>
                        <option value="1" <?php echo e(request('sort') == 1 ? 'selected' : ''); ?>>По году производства: Сначала новые</option>
                        <option value="2" <?php echo e(request('sort') == 2 ? 'selected' : ''); ?>>По году производства: Сначала старые</option>
                        <option value="3" <?php echo e(request('sort') == 3 ? 'selected' : ''); ?>>По наименованию: от А-Я</option>
                        <option value="4" <?php echo e(request('sort') == 4 ? 'selected' : ''); ?>>По наименованию: от Я-А</option>
                        <option value="5" <?php echo e(request('sort') == 5 ? 'selected' : ''); ?>>По цене: Сначала дорогие</option>
                        <option value="6" <?php echo e(request('sort') == 6 ? 'selected' : ''); ?>>По цене: Сначала дешевые</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label text-muted small fw-bold">Категория</label>
                    <select class="form-select form-select-lg" name="category">
                        <option value="0" <?php echo e(request('category') == 0 ? 'selected' : ''); ?>>По умолчанию</option>
                        <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cat->id); ?>" <?php echo e(request('category') == $cat->id ? 'selected' : ''); ?>><?php echo e($cat->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary btn-lg flex-grow-1">Найти</button>
                        <a href="<?php echo e(route('catalog')); ?>" class="btn btn-outline-secondary btn-lg flex-grow-1">Сбросить</a>
                    </div>
                </div>
            </div>
        </form>

        <div class="row row-cols-1 row-cols-md-3 g-4">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <div class="card h-100 d-flex flex-column border-0 shadow-sm">
                        <img src="<?php echo e(asset('public/img/' . $product->img)); ?>" alt="<?php echo e($product->name); ?>">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title fw-bold"><?php echo e($product->name); ?></h5>
                            <p class="card-text text-primary fs-5 fw-bold mb-4"><?php echo e(number_format($product->price, 0, '.', ' ')); ?> руб.</p>
                            <a href="<?php echo e(route('product', $product->id)); ?>" class="btn btn-primary mt-auto">Подробнее</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="d-flex justify-content-center mt-5">
        <?php echo e($products->appends(request()->query())->links('pagination::bootstrap-4')); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OSPanel\domains\localhost\resources\views/Catalog.blade.php ENDPATH**/ ?>