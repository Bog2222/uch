<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row g-4">
        <div class="col-lg-6">
            <div class="card border-0 shadow-sm">
                <?php if($product->img): ?>
                    <img src="<?php echo e(asset('public/img/' . $product->img)); ?>" class="card-img-top w-100 object-fit-cover" style="max-height: 500px;" alt="<?php echo e($product->name); ?>">
                <?php endif; ?>
            </div>
        </div>

        <div class="col-lg-6">
            <h1 class="display-6 fw-bold mb-3"><?php echo e($product->name); ?></h1>
            <h2 class="h3 text-primary fw-bold mb-4"><?php echo e(number_format($product->price, 0, '.', ' ')); ?> руб.</h2>

            <div class="mb-4">
                <ul class="list-unstyled">
                    <li class="mb-2"><strong>Страна:</strong> <?php echo e($product->country); ?></li>
                    <li class="mb-2"><strong>Год:</strong> <?php echo e($product->year); ?></li>
                    <li class="mb-2"><strong>Модель:</strong> <?php echo e($product->model); ?></li>
                    <li class="mb-2"><strong>Категория:</strong> <?php echo e($product->category ? $product->category->name : 'Не указана'); ?></li>
                    <li class="mb-2"><strong>В наличии:</strong> <?php echo e($product->quantity); ?> шт.</li>
                </ul>
            </div>

            <div class="d-grid gap-2 d-md-flex mt-5">
                <form action="<?php echo e(route('cart.add')); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                    <button type="submit" class="btn btn-primary btn-lg px-5" <?php echo e($product->quantity <= 0 ? 'disabled' : ''); ?>>
                        <?php echo e($product->quantity <= 0 ? 'Нет в наличии' : 'В корзину'); ?>

                    </button>
                </form>
                <a href="<?php echo e(route('catalog')); ?>" class="btn btn-outline-secondary btn-lg">Назад</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer543\domains\localhost\resources\views/product.blade.php ENDPATH**/ ?>