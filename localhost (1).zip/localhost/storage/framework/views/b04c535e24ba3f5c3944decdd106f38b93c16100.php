<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <h1 class="mb-4">Мои заказы</h1>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <?php if($orders->isEmpty()): ?>
            <div class="text-center py-5">
                <h3>У вас пока нет заказов</h3>
                <a href="<?php echo e(route('catalog')); ?>" class="btn btn-primary mt-3">Перейти в каталог</a>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-bordered align-middle">
                    <thead class="table-light">
                    <tr>
                        <th>Заказ</th>
                        <th>Количество товаров</th>
                        <th>Статус</th>
                        <th>Итоговая цена</th>
                        <th>Дата оформления</th>
                        <th>Удаление</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <button type="button" class="btn btn-link p-0 text-decoration-none fw-bold" data-bs-toggle="modal" data-bs-target="#userOrderModal<?php echo e($order->id); ?>">
                                    #<?php echo e($order->id); ?>

                                </button>
                            </td>
                            <td><?php echo e($order->quantity); ?> шт.</td>
                            <td>
                            <span class="badge <?php echo e($order->status_id == 1 ? 'bg-success' : ($order->status_id == 3 ? 'bg-danger' : 'bg-warning')); ?>">
                                <?php echo e($order->status->name ?? 'Неизвестно'); ?>

                            </span>
                            </td>
                            <td><?php echo e(number_format($order->total_price, 0, '.', ' ')); ?> руб.</td>
                            <td><?php echo e($order->created_at ? $order->created_at->format('d.m.Y H:i') : '—'); ?></td>
                            <td>
                                <?php if($order->status_id == 2): ?>
                                    <form action="<?php echo e(route('order.delete', $order->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Удалить заказ?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger">Удалить</button>
                                    </form>
                                <?php else: ?>
                                    <span class="text-muted small">Недоступно</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="modal fade" id="userOrderModal<?php echo e($order->id); ?>" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog modal-lg modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Детали заказа #<?php echo e($order->id); ?></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered align-middle">
                                        <thead class="table-light">
                                        <tr>
                                            <th>Товар</th>
                                            <th>Количество</th>
                                            <th>Цена</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($item->product->name ?? 'Товар удален'); ?></td>
                                                <td><?php echo e($item->quantity); ?> шт.</td>
                                                <td><?php echo e(number_format(($item->product->price ?? 0) * $item->quantity, 0, '.', ' ')); ?> руб.</td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="text-end mt-3">
                                    <h4>Итого: <?php echo e(number_format($order->total_price, 0, '.', ' ')); ?> руб.</h4>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Закрыть</button>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer543\domains\localhost\resources\views/order.blade.php ENDPATH**/ ?>