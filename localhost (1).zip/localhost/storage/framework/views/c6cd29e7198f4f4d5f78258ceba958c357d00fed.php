<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Админ-панель </h1>
        <a href="<?php echo e(route('admin-products')); ?>" class="btn btn-primary btn-lg px-5">Управление товарами</a>
        <a href="<?php echo e(route('admin-catygories')); ?>" class="btn btn-primary btn-lg px-5">Управление категориями</a>
        <a href="<?php echo e(route('admin-orders')); ?>" class="btn btn-primary btn-lg px-5">Управление заказами</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\localhost\resources\views/admin.blade.php ENDPATH**/ ?>