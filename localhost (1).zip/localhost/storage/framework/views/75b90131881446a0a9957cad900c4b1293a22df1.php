<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <h1 class="mb-4">Ваша корзина</h1>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <?php if($cartItems->isEmpty()): ?>
            <div class="text-center py-5">
                <h3>Корзина пуста</h3>
                <a href="<?php echo e(route('catalog')); ?>" class="btn btn-primary mt-3">Перейти в каталог</a>
            </div>
        <?php else: ?>

            <div class="card border-0 shadow-sm">
                <div class="card-body">
                    <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="row align-items-center mb-3 pb-3 border-bottom">
                            <div class="col-md-2">
                                <?php if($item->img): ?>
                                    <img src="<?php echo e(asset('public/img/' . $item->img)); ?>" class="img-fluid rounded" alt="<?php echo e($item->name); ?>" style="max-width: 80px;">
                                <?php endif; ?>
                            </div>
                            <div class="col-md-4">
                                <h6 class="mb-1"><?php echo e($item->name); ?></h6>
                                <small class="text-muted"><?php echo e($item->model); ?></small>
                            </div>
                            <div class="col-md-2">
                                <span class="text-primary fw-bold"><?php echo e(number_format($item->price, 0, '.', ' ')); ?> руб.</span>
                            </div>
                            <div class="col-md-2">
                                <div class="d-flex justify-content-center align-items-center">
                                    <form action="<?php echo e(route('cart.minus')); ?>" method="POST" class="d-inline">
                                        <?php echo method_field('PATCH'); ?>
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="product_id" value="<?php echo e($item->product_id); ?>">
                                        <button class="btn btn-sm btn-outline-secondary" type="submit">-</button>
                                    </form>

                                    <div class="mx-2" style="width: 60px;">
                                        <input type="text" value="<?php echo e($item->quantity); ?>" class="form-control form-control-sm" style="width: 50px" readonly>
                                    </div>

                                    <form action="<?php echo e(route('cart.plus')); ?>" method="POST" class="d-inline">
                                        <?php echo method_field('PATCH'); ?>
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="product_id" value="<?php echo e($item->product_id); ?>">
                                        <button class="btn btn-sm btn-outline-secondary" type="submit" <?php echo e($item->quantity >= $item->max_quantity ? 'disabled' : ''); ?>>+</button>
                                    </form>
                                </div>
                            </div>
                            <div class="col-md-2 text-end" style="margin-left: 7px">
                                <a href="<?php echo e(route('cart.remove', $item->product_id)); ?>" class="btn btn-sm btn-outline-danger">Удалить</a>
                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="row mt-3">
                        <div class="col-md-6">
                            <h4>Итого: <?php echo e(number_format($totalPrice, 0, '.', ' ')); ?> руб.</h4>
                        </div>
                    </div>

                    <hr>

                    <div class="row">
                        <div class="col-md-12 text-end">
                            <button type="button" class="btn btn-success btn-lg" data-bs-toggle="modal" data-bs-target="#passwordModal">
                                Оформить заказ
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <div class="modal fade <?php if($errors->has('password')): ?> show <?php endif; ?>" id="passwordModal" tabindex="-1" aria-labelledby="passwordModalLabel" aria-hidden="true" <?php if($errors->has('password')): ?> style="display: block; background: rgba(0,0,0,0.5);" <?php endif; ?>>
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="passwordModalLabel">Подтверждение заказа</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" onclick="this.closest('.modal').style.display='none'"></button>
                </div>
                <form action="<?php echo e(route('order.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="password" class="form-label">Введите пароль для подтверждения заказа:</label>
                            <input type="password" name="password" id="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onclick="this.closest('.modal').style.display='none'">Отмена</button>
                        <button type="submit" class="btn btn-success">Сформировать заказ</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OSPanel\domains\localhost\resources\views/cart.blade.php ENDPATH**/ ?>