<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="mb-3">
            <a href="?status=В обработке" class="btn btn-sm btn-info">Новые</a>
            <a href="?status=подтвержденные" class="btn btn-sm btn-success">Подтвержденные</a>
            <a href="?status=Отменено" class="btn btn-sm btn-danger">Отмененные</a>
            <a href="?" class="btn btn-sm btn-secondary">Все</a>
        </div>

        <table class="table">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">ФИО заказчика</th>
                <th scope="col">Кол-во товаров</th>
                <th scope="col">Статус</th>
                <th scope="col">Причина отмены</th>
                <th scope="col">Действия</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $quantity = \Illuminate\Support\Facades\DB::table('order_items')
                        ->where('order_id', $order->id)
                        ->sum('quantity');
                ?>
                <tr>
                    <th scope="row"><?php echo e($order->id); ?></th>
                    <td><?php echo e($order->user->name ?? 'Неизвестный'); ?></td>
                    <td><?php echo e($quantity); ?> шт.</td>
                    <td><?php echo e($order->status->name ?? '—'); ?></td>
                    <td><?php echo e($order->rejection ?? '—'); ?></td>
                    <td>
                        <?php if($order->status_id == 2): ?>
                            <form action="<?php echo e(route('admin-orders.confirm', $order->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-success">Подтвердить</button>
                            </form>

                            <form action="<?php echo e(route('admin-orders.reject', $order->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <input type="text" name="rejection" placeholder="Причина отмены" required>
                                <button type="submit" class="btn btn-sm btn-danger">Отменить</button>
                            </form>
                        <?php else: ?>
                            <span class="text-muted">Завершен</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <a href="<?php echo e(route('admin')); ?>" class="btn btn-outline-secondary">Назад</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\localhost\resources\views/admin_orders.blade.php ENDPATH**/ ?>