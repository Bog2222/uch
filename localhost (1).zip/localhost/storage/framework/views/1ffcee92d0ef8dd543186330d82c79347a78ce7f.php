<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <h1 class="mb-4 text-center">Где нас найти?</h1>

        <div class="row g-4">
            <div class="col-md-6">
                <div class="card h-100">
                    <div class="card-body p-0 overflow-hidden">
                        <iframe
                            src="https://yandex.ru/map-widget/v1/?ll=53.211628%2C56.861676&mode=poi&poi%5Bpoint%5D=53.211317%2C56.861452&poi%5Buri%5D=ymapsbm1%3A%2F%2Forg%3Foid%3D127212827101&z=18.63"
                            class="w-100"
                            style="min-height: 400px; border: none;"
                            allowfullscreen="true"
                            loading="lazy">
                        </iframe>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card h-100">
                    <div class="card-body">
                        <h2 class="h4 mb-4">Контактные данные</h2>

                        <div class="mb-4">
                            <h3 class="h6 text-muted mb-1">Адрес</h3>
                            <p class="mb-0 fs-5">г. Ижевск, ул. Домашняя, д. 1</p>
                        </div>

                        <div class="mb-4">
                            <h3 class="h6 text-muted mb-1">Телефон</h3>
                            <p class="mb-0 fs-5">
                                <a href="tel:+73412000000" class="text-decoration-none text-dark">+7 (3412) 00-00-00</a>
                            </p>
                        </div>

                        <div class="mb-4">
                            <h3 class="h6 text-muted mb-1">Email</h3>
                            <p class="mb-0 fs-5">
                                <a href="mailto:info@veu.ru" class="text-decoration-none text-dark">info@veu.ru</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer543\domains\localhost\resources\views/find_us.blade.php ENDPATH**/ ?>