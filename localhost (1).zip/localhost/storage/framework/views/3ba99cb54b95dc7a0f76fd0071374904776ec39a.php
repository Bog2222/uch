<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <h1 class="mb-4">Мои заказы</h1>

        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <?php if($orders->isEmpty()): ?>
            <div class="text-center py-5">
                <h3>У вас пока нет заказов</h3>
                <a href="<?php echo e(route('catalog')); ?>" class="btn btn-primary mt-3">Перейти в каталог</a>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class="table-light">
                    <tr>
                        <th>Заказ</th>
                        <th>Количество товаров</th>
                        <th>Статус</th>
                        <th>Итоговая цена</th>
                        <th>Действия</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>#<?php echo e($order->id); ?></td>
                            <td><?php echo e($order->quantity); ?> шт.</td>
                            <td>
                            <span class="badge <?php echo e($order->status_id == 1 ? 'bg-success' : ($order->status_id == 3 ? 'bg-danger' : 'bg-warning')); ?>">
                                <?php echo e($order->status->name ?? 'Неизвестно'); ?>

                            </span>
                            </td>
                            <td><?php echo e(number_format($order->total_price, 0, '.', ' ')); ?> руб.</td>
                            <td>
                                <form action="<?php echo e(route('order.delete', $order->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Удалить заказ?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger">Удалить</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>

        <a href="<?php echo e(route('catalog')); ?>" class="btn btn-outline-secondary mt-3">Назад в каталог</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\localhost\resources\views/order.blade.php ENDPATH**/ ?>