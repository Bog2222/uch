<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MainController;
use App\Http\Controllers\CatalogController;
use App\Http\Controllers\LkController;
use App\Http\Controllers\AdminController;

Route::get('/', [MainController::class, 'about'])->name('about');
Route::get('/find_us', [MainController::class, 'find_us'])->name('find_us');

Route::get('/catalog', [CatalogController::class, 'index'])->name('catalog');
Route::get('/catalog/{id}', [CatalogController::class, 'product'])->name('product');

Route::get('/cart', [LkController::class, 'cart'])->name('cart');
Route::post('/cart/add', [LkController::class, 'addToCart'])->name('cart.add');
Route::post('/cart/update', [LkController::class, 'updateQuantity'])->name('cart.update');
Route::get('/cart/remove/{product_id}', [LkController::class, 'removeFromCart'])->name('cart.remove');
Route::patch('/cart/plus', [LkController::class, 'plusCart'])->name('cart.plus');
Route::patch('/cart/minus', [LkController::class, 'minusCart'])->name('cart.minus');

Route::get('/order', [LkController::class, 'order'])->name('order');
Route::post('/order', [LkController::class, 'storeOrder'])->name('order.store');
Route::delete('/order/{id}', [LkController::class, 'deleteOrder'])->name('order.delete');

// Админка
Route::get('/admin', [AdminController::class, 'admin'])->name('admin');

// Категории
Route::get('/admin_catygories', [AdminController::class, 'admin_catygories'])->name('admin-catygories');
Route::post('/admin_catygories', [AdminController::class, 'storeCategory'])->name('admin-categories.store');
Route::delete('/admin_catygories/{id}', [AdminController::class, 'destroyCategory'])->name('admin-categories.destroy');

// Заказы
Route::get('/admin_orders', [AdminController::class, 'admin_orders'])->name('admin-orders');
Route::post('/admin_orders/{id}/confirm', [AdminController::class, 'confirmOrder'])->name('admin-orders.confirm');
Route::post('/admin_orders/{id}/reject', [AdminController::class, 'rejectOrder'])->name('admin-orders.reject');

// Товары
Route::get('/admin_products', [AdminController::class, 'admin_products'])->name('admin-products');
Route::post('/admin_products', [AdminController::class, 'product_create'])->name('product.create');
Route::get('/admin/product/update/{id}', [AdminController::class, 'update'])->name('admin.product.update');
Route::put('/admin/product/update', [AdminController::class, 'product_update'])->name('product.update');
Route::delete('/admin/product/delete', [AdminController::class, 'product_delete'])->name('product.delete');

Auth::routes();
Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
